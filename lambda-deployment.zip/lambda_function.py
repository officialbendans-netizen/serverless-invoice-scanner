import json
import boto3
import uuid
import io
from datetime import datetime
from pypdf import PdfReader

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('invoice-results')
BUCKET_NAME = 'invoice-scanner-uploads-benjamin'

HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
}


def extract_text_from_pdf(file_bytes):
    """Extract text from PDF using pypdf. Falls back to a placeholder
    if the PDF has no text layer (i.e. it's a scanned/image-only PDF)."""
    try:
        reader = PdfReader(io.BytesIO(file_bytes))
        lines = []

        for page in reader.pages:
            text = page.extract_text() or ""
            for raw_line in text.split('\n'):
                cleaned = raw_line.strip()
                if len(cleaned) > 1:
                    lines.append(cleaned)

        if lines:
            print(f"Extracted {len(lines)} lines from PDF ({len(reader.pages)} pages)")
            return lines
        else:
            # No text layer found — this PDF is likely scanned/image-based.
            # pypdf can't OCR it; you'd need pytesseract or Textract for that.
            print("No text layer found — PDF may be scanned/image-based")
            return [
                "PDF uploaded successfully to Amazon S3",
                f"File size: {len(file_bytes)} bytes",
                "No extractable text layer found (this PDF may be a scanned image).",
                "Consider OCR (pytesseract) if this happens frequently."
            ]

    except Exception as e:
        print(f"PDF extraction error: {str(e)}")
        return [
            "PDF uploaded and stored in S3",
            f"File size: {len(file_bytes)} bytes",
            f"Text extraction failed: {str(e)}"
        ]


def lambda_handler(event, context):
    print(f"EVENT: {json.dumps(event)}")

    if event.get('httpMethod') == 'OPTIONS':
        return {'statusCode': 200, 'headers': HEADERS, 'body': 'OK'}

    # GET — presigned URL or fetch results
    if event.get('httpMethod') == 'GET':
        try:
            params = event.get('queryStringParameters') or {}

            if 'invoiceId' in params:
                invoice_id = params['invoiceId']
                print(f"Fetching invoiceId: {invoice_id}")
                response = table.get_item(Key={'invoiceid': invoice_id})
                item = response.get('Item', {})
                if not item:
                    return {'statusCode': 404, 'headers': HEADERS,
                            'body': json.dumps({'error': 'Not found'})}
                return {'statusCode': 200, 'headers': HEADERS,
                        'body': json.dumps(item, default=str)}

            filename = params.get('filename', 'invoice.pdf')
            file_type = params.get('fileType', 'application/pdf')
            invoice_id = str(uuid.uuid4())
            s3_key = f"invoices/{invoice_id}/{filename}"

            presigned_url = s3_client.generate_presigned_url(
                'put_object',
                Params={
                    'Bucket': BUCKET_NAME,
                    'Key': s3_key,
                    'ContentType': file_type
                },
                ExpiresIn=300
            )
            return {'statusCode': 200, 'headers': HEADERS,
                    'body': json.dumps({
                        'uploadUrl': presigned_url,
                        'invoiceId': invoice_id,
                        's3Key': s3_key
                    })}

        except Exception as e:
            print(f"GET ERROR: {str(e)}")
            return {'statusCode': 500, 'headers': HEADERS,
                    'body': json.dumps({'error': str(e)})}

    # S3 TRIGGER — extract text from PDF
    if event.get('Records'):
        print(f"S3 TRIGGER — {len(event['Records'])} record(s)")
        for record in event['Records']:
            try:
                bucket = record['s3']['bucket']['name']
                s3_key = record['s3']['object']['key']
                print(f"Processing: {s3_key}")

                parts = s3_key.split('/')
                invoice_id = parts[1] if len(parts) > 1 else str(uuid.uuid4())
                filename = parts[2] if len(parts) > 2 else s3_key

                # Download file from S3
                print("Downloading from S3...")
                s3_obj = s3_client.get_object(Bucket=bucket, Key=s3_key)
                file_bytes = s3_obj['Body'].read()
                print(f"Downloaded {len(file_bytes)} bytes")

                # Extract text
                print("Extracting text from PDF...")
                lines = extract_text_from_pdf(file_bytes)
                extracted_text = '\n'.join(lines)

                # Save results to DynamoDB
                table.put_item(Item={
                    'invoiceid': invoice_id,
                    'filename': filename,
                    's3Key': s3_key,
                    'extractedText': extracted_text,
                    'lineCount': len(lines),
                    'processedAt': datetime.utcnow().isoformat(),
                    'status': 'completed'
                })
                print(f"Saved results for invoiceId: {invoice_id}")

            except Exception as e:
                print(f"S3 TRIGGER ERROR: {str(e)}")
                try:
                    table.put_item(Item={
                        'invoiceid': invoice_id,
                        'status': 'failed',
                        'error': str(e),
                        'processedAt': datetime.utcnow().isoformat()
                    })
                except Exception:
                    pass

        return {'statusCode': 200, 'headers': HEADERS,
                'body': json.dumps({'message': 'Processing complete'})}

    return {'statusCode': 400, 'headers': HEADERS,
            'body': json.dumps({'error': 'Unsupported event type'})}
